import { BrowserRouter, Routes, Route } from "react-router-dom"
import Signup from "./pages/signup/Signup"
import Signin from "./pages/signin/Signin"
import Landing from "./pages/landing/Landing"
import PublicRoutes from "./routes/publicRoutes"
import Home from "./pages/home/Home"
import ProtectedRoutes from "./routes/protectedRoutes"

const App = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route element={<PublicRoutes />} >
            <Route path="/" element={<Landing />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/signin" element={<Signin />} />
          </Route>

          <Route element={<ProtectedRoutes />}>
            <Route path="/home" element={<Home />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App