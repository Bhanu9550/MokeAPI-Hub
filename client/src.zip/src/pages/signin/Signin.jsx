import { useState } from "react"
import axios from "axios"

const Signin = () => {
    const [details, setDetails] = useState({
        username : ""
    })

    function updateDetails(e){
        e.preventDefault()
        setDetails({ ...details, [e.target.id] : e.target.value})
    }

    async function createAcc(){
        try{
            const response = await axios.post('http://localhost:8080/signin', details, {withCredentials: true})
            setDetails({username : ""})
            console.log(response)
        }catch(err){
            console.log(err.message)
        }
    }

    return (
    <>
        <h2>signIn</h2>
        <input type="text" value={details.username} id="username" placeholder="enter username" onChange={(event)=> updateDetails(event)}/>
        <button onClick={createAcc}>signIn</button>
    </>
  )
}

export default Signin;