// import { useContext } from "react"
// import {Link} from "react-router-dom"
// import UserContext from "../../context/userContext"

const Landing = () => {
  // const {user} = useContext(UserContext)
  return (  
    <>
        <div>Landing</div>
        {/* {user? 
          <>
            <h2>helloloo</h2>
            <Link to="/home">Home</Link>
          </>: 
          <>
            <Link to="/signup">SignUp</Link> <br ></br>
            <Link to="/signin">SignIn</Link>
          </>
        }  */}
    </>
  )
}

export default Landing;