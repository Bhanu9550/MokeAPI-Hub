import { useState } from "react"
import axios from "axios"
import {useNavigate} from "react-router-dom"

const Signup = () => {

    const [details, setDetails] = useState({
        username : ""
    })

    const navigate = useNavigate()

    function updateDetails(e){
        e.preventDefault()
        setDetails({ ...details, [e.target.id] : e.target.value})
    }

    async function createAcc(){
        try{
            await axios.post('http://localhost:8080/signup', details)
            setDetails({username : ""})
            navigate("/signin")
            
        }catch(err){
            console.log(err.message)
        }
    }

    return (
    <>
        <h2>signUp</h2>
        <input type="text" value={details.username} id="username" placeholder="enter username" onChange={(event)=> updateDetails(event)}/>
        <button onClick={createAcc}>signUp</button>
    </>
  )
}

export default Signup