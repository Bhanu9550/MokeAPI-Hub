import { useContext } from "react"
import UserContext from "../context/userContext"
import { Navigate, Outlet } from "react-router-dom"

const ProtectedRoutes = () => {
    const { user, loading} = useContext(UserContext)
    
    if(loading){
        return(
            <h2>Loading........</h2>
        )
    }

    if(!user){
        return <Navigate  to="/signin" replace />
    }
    return <Outlet />
}

export default ProtectedRoutes;
