import { useContext } from "react"
import UserContext from "../context/userContext"
import { Navigate, Outlet } from "react-router-dom"


const PublicRoutes = () => {
    const { user, loading} = useContext(UserContext)
   
    if(loading){
        return(
            <h2>Loading........</h2>
        )
    }

    if(!user){
        return <Outlet />
    }
    return <Navigate  to="/home" replace />

}

export default PublicRoutes